#!/usr/bin/env bash
###############################################################################
# sv_calling_delly.sh
# Author : lunping.liang
# Purpose: Delly two‑pass SV discovery, merge, filter (germline), convert to VCF
###############################################################################

set -euo pipefail

######################## USER‑CONFIGURABLE PARAMETERS #########################
WORKDIR="/data/project/305"
BAM_DIR="${WORKDIR}/bams"                    
REF="/data/ref/IRGSP-1.0_genome.fasta"
THREADS=20

DELLY="/opt/miniconda/envs/delly/bin/delly"
BCFTOOLS="/opt/miniconda/envs/bcftools/bin/bcftools"
PARALLEL="/usr/bin/parallel"
###############################################################################

mkdir -p "${WORKDIR}/SV"                    # outdir
cd "$WORKDIR"

########################################################################
# Step 1: first‑pass per‑sample calling → SV/step01.delly1st/*.bcf
########################################################################
echo ">>> [Step1] Delly first‑pass per‑sample calling"
mkdir -p SV/step01.delly1st
find "$BAM_DIR" -name "*.bam" | sort -V | while read -r BAM; do
  SAMPLE=$(basename "$BAM" .bam)
  echo "$DELLY call -g $REF -o SV/step01.delly1st/${SAMPLE}.bcf $BAM"
done > step01.delly1st.cmds

nohup $PARALLEL -j "$THREADS" < step01.delly1st.cmds \
      2> logs_delly_step01.err &

########################################################################
# Step 2: merge first‑pass sites → sites.bcf
########################################################################
echo ">>> [Step2] Merge first‑pass BCF to sites.bcf"
mkdir -p SV/step02.merge1st
FIRST_BCF=$(ls SV/step01.delly1st/*.bcf | sort -V | tr '\n' ' ')
$DELLY merge -o SV/step02.merge1st/sites.bcf $FIRST_BCF

########################################################################
# Step 3: second‑pass re‑calling using consolidated sites
########################################################################
echo ">>> [Step3] Delly second‑pass calling (genotyping)"
mkdir -p SV/step03.delly2nd
find "$BAM_DIR" -name "*.bam" | sort -V | while read -r BAM; do
  SAMPLE=$(basename "$BAM" .bam)
  echo "$DELLY call -g $REF -v SV/step02.merge1st/sites.bcf \
        -o SV/step03.delly2nd/${SAMPLE}.bcf $BAM"
done > step03.delly2nd.cmds

nohup $PARALLEL -j "$THREADS" < step03.delly2nd.cmds \
      > step03.delly2nd.log 2>&1 &

########################################################################
# Step 4: merge second‑pass BCFs → merged.bcf (+ index + VCF convert)
########################################################################
echo ">>> [Step4] Merge second‑pass BCFs"
mkdir -p SV/step04.merge2nd
SECOND_BCF=$(ls SV/step03.delly2nd/*.bcf | sort -V | tr '\n' ' ')
$BCFTOOLS merge -m id -O b -o SV/step04.merge2nd/merged.bcf $SECOND_BCF
$BCFTOOLS index SV/step04.merge2nd/merged.bcf
$BCFTOOLS convert -O v -o SV/step04.merge2nd/merged.vcf SV/step04.merge2nd/merged.bcf

########################################################################
# Step 5: germline filter → PASS variants
########################################################################
echo ">>> [Step5] Germline filtering + PASS extraction"
mkdir -p SV/step05.filter
$DELLY filter -f germline -o SV/step05.filter/germline.bcf SV/step04.merge2nd/merged.bcf
$BCFTOOLS convert -O v -o SV/step05.filter/germline.vcf SV/step05.filter/germline.bcf

# Keep only PASS lines
awk 'BEGIN{FS=OFS="\t"} /^#/ {print; next} $7=="PASS" {print}' \
    SV/step05.filter/germline.vcf > SV/step05.filter/germline.pass.vcf

echo ">>> DONE. result file  SV/step05.filter/germline.pass.vcf"
