#!/usr/bin/env bash
###############################################################################
# snp_calling.sh
# Author : lunping.liang
# Purpose: Fastq → BAM → GVCF → joint‑genotyped VCF  (SNP & INDEL)
###############################################################################

set -euo pipefail

######################## USER‑CONFIGURABLE PARAMETERS #########################
WORKDIR="/data/project/305"              # project dir
RAW_FQ_DIR="${WORKDIR}/fq/rawdata"       # raw fastq dir
CLEAN_FQ_DIR="${WORKDIR}/fq/clean"       # clean fastp dir
REF="/data/ref/IRGSP-1.0_genome.fasta"   # ref
THREADS=8
SAMPLE_LIST="${WORKDIR}/samples.txt"     # per row with one sample

# 软件路径
FASTP="/usr/bin/fastp"
BWA="/usr/bin/bwa"
SAMTOOLS="/usr/bin/samtools"
SAMBAMBA="/usr/bin/sambamba"
GATK="/usr/bin/gatk"                     # GATK4+
###############################################################################

LOGDIR="${WORKDIR}/logs"
OUT_BAM_DIR="${WORKDIR}/01.BWA/bam"
OUT_GVCF_DIR="${WORKDIR}/02.VCF/gvcf"
OUT_VCF_DIR="${WORKDIR}/02.VCF/raw"

mkdir -p "$LOGDIR" "$CLEAN_FQ_DIR" "$OUT_BAM_DIR" "$OUT_GVCF_DIR" "$OUT_VCF_DIR"

echo ">>> [Step1] fastp quality‑control"
while read -r SAMPLE; do
  fq1="${RAW_FQ_DIR}/${SAMPLE}.R1.fq.gz"
  fq2="${RAW_FQ_DIR}/${SAMPLE}.R2.fq.gz"
  fq1_clean="${CLEAN_FQ_DIR}/${SAMPLE}_1.clean.fq.gz"
  fq2_clean="${CLEAN_FQ_DIR}/${SAMPLE}_2.clean.fq.gz"

  $FASTP -i "$fq1" -I "$fq2" -o "$fq1_clean" -O "$fq2_clean" \
         --qualified_quality_phred 20 --unqualified_percent_limit 0 \
         --disable_trim_poly_g --thread "$THREADS" --cut_tail --cut_front \
         --json "${CLEAN_FQ_DIR}/${SAMPLE}_fastp.json" \
         --html "${CLEAN_FQ_DIR}/${SAMPLE}_fastp.html" \
         2> "${LOGDIR}/${SAMPLE}_fastp.log"
done < "$SAMPLE_LIST"

echo ">>> [Step2] BWA‑MEM mapping → sorted BAM"
while read -r SAMPLE; do
  fq1="${CLEAN_FQ_DIR}/${SAMPLE}_1.clean.fq.gz"
  fq2="${CLEAN_FQ_DIR}/${SAMPLE}_2.clean.fq.gz"
  bam="${OUT_BAM_DIR}/${SAMPLE}.sorted.bam"

  $BWA mem -R "@RG\tID:${SAMPLE}\tPL:illumina\tSM:${SAMPLE}" -t "$THREADS" "$REF" "$fq1" "$fq2" |
    $SAMTOOLS sort -@ "$THREADS" -o "$bam"
  $SAMTOOLS index "$bam"
done < "$SAMPLE_LIST"

echo ">>> [Step3] Mark duplicates (Sambamba)"
while read -r SAMPLE; do
  inbam="${OUT_BAM_DIR}/${SAMPLE}.sorted.bam"
  outbam="${OUT_BAM_DIR}/${SAMPLE}.sorted.rmdup.bam"

  $SAMBAMBA markdup -r -t "$THREADS" "$inbam" "$outbam" \
    > "${LOGDIR}/${SAMPLE}_markdup.log" 2>&1
  $SAMTOOLS index "$outbam"
done < "$SAMPLE_LIST"

echo ">>> [Step4] GATK	HaplotypeCaller	→ per‑sample GVCF"
while read -r SAMPLE; do
  inbam="${OUT_BAM_DIR}/${SAMPLE}.sorted.rmdup.bam"
  gvcf="${OUT_GVCF_DIR}/${SAMPLE}.g.vcf.gz"

  $GATK --java-options "-Xmx8g" HaplotypeCaller \
        -R "$REF" -I "$inbam" -O "$gvcf" -ERC GVCF \
        > "${LOGDIR}/${SAMPLE}_HC.log" 2>&1
done < "$SAMPLE_LIST"

echo ">>> [Step5] CombineGVCFs → GenotypeGVCFs"
GVCF_LIST=$(printf " -V %s" ${OUT_GVCF_DIR}/*.g.vcf.gz)
$GATK --java-options "-Xmx32g" CombineGVCFs -R "$REF" $GVCF_LIST \
      -O "${OUT_GVCF_DIR}/combined.g.vcf.gz"
$GATK --java-options "-Xmx32g" GenotypeGVCFs -R "$REF" \
      -V "${OUT_GVCF_DIR}/combined.g.vcf.gz" \
      -O "${OUT_VCF_DIR}/raw_variants.vcf.gz"

echo ">>> [Step6] Variant filtering & hard‑filters"
$GATK SelectVariants -R "$REF" -V "${OUT_VCF_DIR}/raw_variants.vcf.gz" \
      --select-type-to-include SNP -O "${OUT_VCF_DIR}/raw_SNP.vcf.gz"
$GATK SelectVariants -R "$REF" -V "${OUT_VCF_DIR}/raw_variants.vcf.gz" \
      --select-type-to-include INDEL -O "${OUT_VCF_DIR}/raw_INDEL.vcf.gz"


$GATK VariantFiltration -R "$REF" -V "${OUT_VCF_DIR}/raw_SNP.vcf.gz" \
      --filter-expression "QD < 2.0 || FS > 60.0 || MQ < 40.0 || SOR > 3.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0" \
      --filter-name "SNP_FILTER" \
      -O "${OUT_VCF_DIR}/filtered_SNP.vcf.gz"
$GATK VariantFiltration -R "$REF" -V "${OUT_VCF_DIR}/raw_INDEL.vcf.gz" \
      --filter-expression "QD < 2.0 || FS > 200.0 || SOR > 10.0 || MQRankSum < -12.5 || ReadPosRankSum < -20.0" \
      --filter-name "INDEL_FILTER" \
      -O "${OUT_VCF_DIR}/filtered_INDEL.vcf.gz"

echo ">>> DONE. 结果位于 ${OUT_VCF_DIR}"
