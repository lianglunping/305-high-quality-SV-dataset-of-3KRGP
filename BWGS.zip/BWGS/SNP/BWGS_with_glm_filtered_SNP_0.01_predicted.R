# ============================
# Load required packages
# ============================
library(bruceR)      # Core data‑handling package
library(tidymodels)  # Data splitting & modelling framework
library(BWGS)        # Genomic selection prediction
library(optparse)    # Command‑line argument parsing

# ----------------------------
# Command‑line argument parsing
# ----------------------------
option_list <- list(
  make_option(c("-p", "--pheno"), type = "character", default = NULL,
              help = "Path to the phenotype data file"),
  make_option(c("-s", "--snp"),   type = "character", default = NULL,
              help = "Path to the SNP genotype file"),
  make_option(c("-S", "--sv"),    type = "character", default = NULL,
              help = "Path to the SV genotype file"),
  make_option(c("-t", "--trait"), type = "character", default = NULL,
              help = "Path to the trait list file"),
  make_option(c("-w", "--work"),  type = "character", default = NULL,
              help = "Path to the working directory")
)
opt_parser <- OptionParser(option_list = option_list)
opt <- parse_args(opt_parser)

# -------------------------------------------------
# Example hard‑coded settings for quick debugging
# (commented out in normal use)
# -------------------------------------------------
# work  <- "/data/GS/305/SNP"
# sv    <- "/data/GS/305/SNP/input/305_SV_Geno.RData"
# snp   <- "/data/GS/305/SNP/input/305_SNP_Geno.RData"
# pheno <- "/data/GS/305/SNP/input/305_phe.RData"
#
# setwd(work)
# load(snp);  snp_geno <- myGD_mat; rm(myGD_mat)
# load(sv);   sv_geno  <- myGD_mat; rm(myGD_mat)
# load(pheno); pheno   <- a;        rm(a)
#
# trait  <- "/data/GS/305/SNP/bin/trait.list.txt"
# traits <- import(trait, header = FALSE)$V1

# ============================
# Data loading
# ============================
setwd(opt$work)

load(opt$snp)
snp_geno <- myGD_mat
rm(myGD_mat)

load(opt$sv)
sv_geno <- myGD_mat
rm(myGD_mat)

load(opt$pheno)
pheno <- a
rm(a)

traits <- import(opt$trait, header = FALSE)$V1

# Add additional phenotype columns from CSV
df <- import("input/305_GW_GL2.csv", as = "tibble")
colnames(df)[1] <- "Code"
pheno <- pheno |> inner_join(df, by = "Code")

# ============================
# Create 5‑fold CV splits
# ============================
set.seed(123)               # Ensure reproducibility
folds <- vfold_cv(pheno, v = 5)

# -------------------------------------------------
# Core analysis for a single trait and fold
# -------------------------------------------------
analyze_trait <- function(trait, pheno_train, pheno_test,
                          snp_geno, df, fold_idx) {
  # ----- SNP filtering & extraction -----
  raw_snp_file <- paste(opt$work, "/rMVP/SNP/GLM/", trait, ".GLM.csv", sep = "")
  raw_snp <- fread(raw_snp_file) %>%
    rename(Pvalue = 8) %>%
    filter(Pvalue < 0.01) %>%
    select(CHROM, POS) %>%
    mutate(num = 1,
           snp_id = paste(CHROM, POS, num, sep = "_"))
  
  # Keep SNPs present in the genotype matrix
  valid_snp_ids     <- raw_snp$snp_id[raw_snp$snp_id %in% colnames(snp_geno)]
  snp_geno_filtered <- snp_geno[, valid_snp_ids, drop = FALSE]
  
  # Split genotype into training vs. prediction sets
  snp_geno_train <- snp_geno_filtered[pheno_train$Code, , drop = FALSE]
  snp_geno_test  <- snp_geno_filtered[pheno_test$Code,  , drop = FALSE]
  
  # Phenotype vector for training
  p <- pheno_train[[trait]]
  names(p) <- pheno_train$Code
  
  # ------------------
  # Model list
  # ------------------
  models <- c("GBLUP", "RF", "EGBLUP", "RR", "BRR",
              "LASSO", "EN", "BL", "BB", "RKHS")
  
  # Loop over each model
  walk(models, function(model_name) {
    output_file <- file.path(
      opt$work, "output",
      paste0("305_glm_filtered_SNP_0.01_", trait, "_",
             model_name, "_", fold_idx, "_predict.csv")
    )
    
    # Prediction
    test_predict <- bwgs.predict(
      geno_train        = snp_geno_train,
      pheno_train       = p,
      geno_target       = snp_geno_test,
      geno.impute.method= "mni",
      predict.method    = model_name,
      MAXNA             = 0.2,
      MAF               = 0.05,
      geno.reduct.method= "NULL",
      reduct.size       = "NULL",
      r2                = "NULL",
      pval              = "NULL",
      MAP               = "NULL"
    )
    
    # Convert to tibble
    test_predict_df <- as_tibble(test_predict, rownames = "Code")
    
    # Merge predictions with extra columns in df
    df_pre <- df %>%
      inner_join(test_predict_df, by = "Code")
    
    # Save results
    export(df_pre, output_file)
  })
}

# ============================
# Main loop: iterate over folds and traits
# ============================
walk(seq_along(folds$splits), function(i) {
  pheno_train <- training(folds$splits[[i]])
  pheno_test  <- testing(folds$splits[[i]])
  
  walk(traits, ~analyze_trait(.x, pheno_train, pheno_test,
                              snp_geno, df, i))
})
