# /*************************************************************************
#   @ File Name    : BWGS_with_SV_and_SNP
#   @ Author       : lunping.liang
#   @ Mail         : lunping98@gmail.com
#   @ Version      : V1
#   @ Desc         : Script purpose description
#       @ Input Files:
#           - Phenotype file        : $ARGV[0]
#           - SNP genotype file     : $ARGV[1]
#           - SV genotype file      : $ARGV[2]
#           - Trait list file       : $ARGV[3]
#       @ Output Files:
#           - Model‑specific prediction results: each model is saved as
#               "305_SNP_with_SV_<trait>_<model>_ac.csv"
#           - SNP count summary file: snp_counts.csv
# ************************************************************************/

#####################################
# Environment preparation
#####################################
# Load required R packages, clear workspace, set working directory

library(pacman)
p_load(bruceR, rrBLUP, BGLR, brnn, glmnet, e1071, randomForest, BWGS,
       argparse, plyr, dplyr, tidyr, purrr)
rm(list = ls())

#####################################
# Argument parsing
#####################################

parser <- ArgumentParser(
  description = "Pipeline for genomic selection (GS): handles phenotype & genotype data and saves model predictions."
)

# Arguments: phenotype file, SNP genotype file, SV genotype file,
# working directory, and trait list file
parser$add_argument(
  "-p", "--pheno", type = "character", required = TRUE,
  help = "Path to the phenotype file containing all samples; each trait is a separate column.",
  metavar = "PhenoFile"
)
parser$add_argument(
  "-s", "--snp", type = "character", required = TRUE,
  help = "Path to the SNP genotype file, typically a matrix of SNP genotypes.",
  metavar = "SnpGenoFile"
)
parser$add_argument(
  "-t", "--trait", type = "character", required = TRUE,
  help = "Path to a text file listing all traits to analyse (one trait per line).",
  metavar = "TraitListFile"
)
parser$add_argument(
  "-w", "--work", type = "character", required = TRUE,
  help = "Absolute path to the working directory that holds both input and output files.",
  metavar = "WorkDir"
)

# Parse command‑line arguments
opt            <- parser$parse_args()
work_dir       <- opt$work
sv_geno_file   <- opt$sv
snp_geno_file  <- opt$snp
pheno_file     <- opt$pheno
traits_file    <- opt$trait

#####################################
# Data loading
#####################################

setwd(work_dir)

load(snp_geno_file)
snp_geno <- myGD_mat
rm(myGD_mat)

load(pheno_file)
pheno <- a
rm(a)

traits      <- fread(traits_file, header = FALSE)
trait_list  <- traits$V1  # retrieve all traits
geno <- snp_geno

walk(trait_list, function(trait) {  
  #####################################
  # Extract phenotype
  #####################################
  ZB1 <- pheno[, trait]
  names(ZB1) <- pheno[, 1]

  #####################################
  # Core GS analysis
  #####################################
  models      <- c("GBLUP", "RF", "EGBLUP", "RR", "BRR",
                   "LASSO", "EN", "BL", "BB", "RKHS")
  file_prefix <- paste(work_dir,
                       "/output/305_SNP",
                       trait, sep = "")
  file_names  <- paste0(file_prefix, "_", models, "_ac.csv")

  # Run each model and save cross‑validation (CV) results
  results <- map2(models, file_names, ~{
    model_name  <- .x
    output_file <- .y
    result <- bwgs.cv(geno, ZB1,
                      geno.impute.method = "mni",
                      predict.method     = model_name,
                      nFolds             = 5,
                      nTimes             = 10)
    write.csv(result$cv, output_file)
    result$cv
  })

  # Combine CV results from all models
  all_model_results <- do.call(cbind, results)
  colnames(all_model_results) <- models

  write.csv(all_model_results,
            paste0(file_prefix, "_all_model_ac.csv"))
})
