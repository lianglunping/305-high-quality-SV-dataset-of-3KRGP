Rscript BWGS_with_SNP.R -p input/305_phe.RData -s input/305_SNP_Geno.RData -t bin/trait.txt -w /data/GS/305/SNP
