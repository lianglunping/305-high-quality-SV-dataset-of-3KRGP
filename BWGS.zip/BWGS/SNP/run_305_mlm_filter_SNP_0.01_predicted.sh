Rscript BWGS_with_filtered_SNP_0.01_predicted.R -p /data/GS/305/SNP/input/305_phe.RData -s /data/GS/305/SNP/input/305_SNP_Geno.RData -S /data/GS/305/SNP/input/305_SV_Geno.RData -t /data/GS/305/SNP/bin/trait.list.txt -w /data/GS/305/SNP

