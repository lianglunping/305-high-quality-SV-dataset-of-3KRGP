#!/usr/bin/env bash
##########################################################################
# File Name: preprare.sh
# Author: lianglunping (E-mail: llp2505568381@163.com)
# description:
# Created Time: Sun 06 Oct 2024 11:34:46 PM CST
#########################################################################
plink=/home/llp/micromamba/envs/NGS/bin/plink
bcftools=/home/llp/micromamba/envs/NGS/bin/bcftools
dir=~/work/GS/453/SNP/input/305

echo start at time `date +%F!'  '%H:%M
# ln -s ~/work/GS/453/SV/305/input/305.id  .

# bcftools view -S 305.id ${dir}/453.vcf > 305.SV.vcf


# ped、map
$plink --vcf 305.SV.vcf --recode 12 --out 305.prune.in
cat 305.prune.in.map | awk '{printf("%s\t%s_%s\t%s\t%s\n",$1,$1,$4,$3,$4)}' > test.map
cp 305.prune.in.map bk.305.prune.in.map
mv test.map 305.prune.in.map
# bed
$plink --noweb --file 305.prune.in --make-bed --out 305.prune.in
# .raw
$plink --bfile 305.prune.in --recodeA --out 305.prune.in

cat 305.prune.in.raw | cut -d" " -f1,7- | sed 's/_[A-Z]//g' >genotype.txt

awk '{i=1;while(i <= NF){col[i]=col[i] $i " ";i=i+1}} END {i=1;while(i<=NF){print col[i];i=i+1}}' genotype.txt | sed 's/[ \t]*$//g' > genotype_transpose.txt

echo "snpid chr pos" >snpsloc.txt
awk '{print $2,"chr"$1,$4}' 305.prune.in.map >>snpsloc.txt
echo finish at time `date +%F!'  '%H:%M
