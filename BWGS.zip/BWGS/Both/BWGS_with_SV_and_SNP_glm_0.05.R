# /*************************************************************************
#   @ File Name    : BWGS_with_SV_and_SNP
#   @ Author       : lunping.liang
#   @ Mail         : lunping98@gmail.com
#   @ Version      : V1
#   @ Desc         : Script for genomic selection (GS)
#       @ Input Files:
#           - Phenotype file        : $ARGV[0]
#           - SNP genotype file     : $ARGV[1]
#           - SV  genotype file     : $ARGV[2]
#           - Trait list file       : $ARGV[3]
#       @ Output Files:
#           - Model‐specific prediction results: each model is saved as
#               "305_SNP_with_SV_<trait>_<model>_ac.csv"
#           - SNP count summary file: snp_counts.csv
# ************************************************************************/

#####################################
# Environment preparation
#####################################
# Load required R packages, clear the workspace, set working directory

library(pacman)
p_load(bruceR, rrBLUP, BGLR, brnn, glmnet, e1071, randomForest, BWGS,
       argparse, plyr, dplyr, tidyr, purrr)
rm(list = ls())

#####################################
# Argument parsing
#####################################

parser <- ArgumentParser(
  description = "Genomic selection (GS) pipeline: processes phenotype & genotype data and saves model predictions."
)

# Arguments: phenotype file, SNP genotype file, SV genotype file, working
# directory, and trait list file
parser$add_argument(
  "-p", "--pheno", type = "character", required = TRUE,
  help = "Path to the phenotype file containing all samples; each trait is a column.",
  metavar = "PhenoFile"
)

parser$add_argument(
  "-s", "--snp", type = "character", required = TRUE,
  help = "Path to the SNP genotype file (typically a matrix of SNP genotypes).",
  metavar = "SnpGenoFile"
)

parser$add_argument(
  "-S", "--sv", type = "character", required = TRUE,
  help = "Path to the SV genotype file containing genotypes at SV loci for each sample.",
  metavar = "SvGenoFile"
)

parser$add_argument(
  "-t", "--trait", type = "character", required = TRUE,
  help = "Path to a text file listing all traits to analyse (one trait per line).",
  metavar = "TraitListFile"
)

parser$add_argument(
  "-w", "--work", type = "character", required = TRUE,
  help = "Absolute path to the working directory that holds both input and output files.",
  metavar = "WorkDir"
)

# Parse command‑line arguments
opt          <- parser$parse_args()
work_dir     <- opt$work
sv_geno_file <- opt$sv
snp_geno_file<- opt$snp
pheno_file   <- opt$pheno
traits_file  <- opt$trait

#####################################
# Data loading
#####################################
setwd(work_dir)
load(sv_geno_file)
sv_geno <- myGD_mat
rm(myGD_mat)

load(snp_geno_file)
snp_geno <- myGD_mat
rm(myGD_mat)

load(pheno_file)
pheno <- a
rm(a)

traits      <- fread(traits_file, header = FALSE)
trait_list  <- traits$V1  # list of traits

#####################################
# Iterate over each trait
#####################################
# To store the number of SNPs and SVs retained per trait
snp_counts <- data.frame(trait = character(),
                         snp_count = integer(),
                         stringsAsFactors = FALSE)

sv_counts  <- data.frame(trait = character(),
                         sv_count = integer(),
                         stringsAsFactors = FALSE)

walk(trait_list, function(trait) {

  #####################################
  # SNP filtering & extraction
  #####################################
  raw_snp_file <- paste(work_dir, "/input/SNP_GLM/", trait, ".GLM.csv", sep = "")
  raw_snp      <- fread(raw_snp_file)

  # Rename column and filter SNPs
  colnames(raw_snp)[8] <- "Pvalue"
  filter_snp <- raw_snp %>%
    filter(Pvalue < 0.05) %>%
    select(CHROM, POS) %>%
    mutate(num = 1) %>%
    unite(snp_id, CHROM, POS, num, sep = "_", remove = FALSE)

  print(head(filter_snp))  # show filtered SNPs

  # Keep only those SNPs present in the genotype matrix
  valid_snp_ids <- filter_snp$snp_id[filter_snp$snp_id %in% colnames(snp_geno)]
  snp_geno_filtered <- snp_geno[, valid_snp_ids]

  # Record count
  snp_count  <- length(valid_snp_ids)
  snp_counts <<- rbind(snp_counts, data.frame(trait = trait,
                                              snp_count = snp_count))

  #####################################
  # SV filtering & extraction
  #####################################
  raw_sv_file <- paste(work_dir, "/input/SV_GLM/", trait, ".GLM.csv", sep = "")
  raw_sv      <- fread(raw_sv_file)

  # Rename column and filter SVs
  colnames(raw_sv)[8] <- "Pvalue"
  filter_sv <- raw_sv %>%
    filter(Pvalue < 0.05) %>%
    select(CHROM, POS) %>%
    mutate(num = 1) %>%
    unite(snp_id, CHROM, POS, num, sep = "_", remove = FALSE)

  print(head(filter_sv))  # show filtered SVs

  valid_sv_ids <- filter_sv$snp_id[filter_sv$snp_id %in% colnames(sv_geno)]
  sv_geno_filtered <- sv_geno[, valid_sv_ids]

  sv_count  <- length(valid_sv_ids)
  sv_counts <<- rbind(sv_counts, data.frame(trait = trait,
                                            sv_count = sv_count))

  # Combine SNP and SV genotype matrices
  geno <- cbind(snp_geno_filtered, sv_geno_filtered)

  #####################################
  # Extract phenotype
  #####################################
  ZB1 <- pheno[, trait]
  names(ZB1) <- pheno[, 1]

  #####################################
  # Core GS analysis
  #####################################
  models       <- c("GBLUP", "RF", "EGBLUP", "RR", "BRR",
                    "LASSO", "EN", "BL", "BB", "RKHS")
  file_prefix  <- paste(work_dir,
                        "/output/305_glm_filterd_SNP_with_filtered_SV_0.05",
                        trait, sep = "")
  file_names   <- paste0(file_prefix, "_", models, "_ac.csv")

  # Run each model and save CV results
  results <- map2(models, file_names, ~{
    model_name  <- .x
    output_file <- .y
    result <- bwgs.cv(geno, ZB1,
                      geno.impute.method = "mni",
                      predict.method     = model_name,
                      nFolds             = 5,
                      nTimes             = 10)
    write.csv(result$cv, output_file)
    result$cv
  })

  # Combine CV results from all models
  all_model_results <- do.call(cbind, results)
  colnames(all_model_results) <- models

  write.csv(all_model_results,
            paste0(file_prefix, "_all_model_ac.csv"))

})

# Save SNP & SV counts per trait
write.csv(snp_counts,
          paste(work_dir, "/output/glm_snp_counts1_0.05.csv", sep = ""),
          row.names = FALSE)

write.csv(sv_counts,
          paste(work_dir, "/output/glm_sv_counts1_0.05.csv", sep = ""),
          row.names = FALSE)
