Rscript BWGS_with_SV_and_SNP_glm_0.001.R -p input/305_phe.RData -s input/305_SNP_Geno.RData -S input/305_SV_Geno.RData -t input/tratis.list.txt -w /data/GS/305/SV_with_SNP

