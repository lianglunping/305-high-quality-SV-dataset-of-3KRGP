/home/llp/micromamba/envs/R4/bin/Rscript BWGS_with_SV_and_SNP.R -p input/305_phe.RData  -S input/305_SV_Geno.RData -t input/tratis.list.txt -w /data/GS/305/SV
