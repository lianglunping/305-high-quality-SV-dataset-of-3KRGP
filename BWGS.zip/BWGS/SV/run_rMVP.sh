echo start at time `date +%F!'  '%H:%M`

Rscript rMVP.R -w /data/GS/305/SV/input -p /data/GS/305/SV/input/305_phe24.txt -b /data/GS/305/SV/input/305.prune.in -o /data/GS/305/SV/output/rMVP

echo finish at time `date +%F!'  '%H:%M`
