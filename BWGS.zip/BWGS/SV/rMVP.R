#!/usr/bin/env Rscript

library(pacman)
p_load(tidyverse,bruceR,argparse,rMVP,ggpubr)
rm(list = ls())

#####################################
# 参数解析
#####################################

parser <- ArgumentParser(description='Run GWAS by rMVP based with GLM/glm/FarmCPU')

parser$add_argument( "-w", "--workdir", type="character", required=F,
                     help="Your work directory (optional). Default is the current directory ('.')",
                     metavar="Workdir",
                     default=".")

parser$add_argument( "-p", "--Phenotype", type="character", required=T,
                     help="your phenotype file!",
                     metavar="PhenotypeFile")

parser$add_argument( "-b", "--bfile", type="character", required=T,
                     help="your VCF file!",
                     metavar="VCFFile")

parser$add_argument( "-o", "--output", type="character", required=T,
                     help="This is your output path",
                     metavar="Outdir")

opt <- parser$parse_args()
phe=opt$Phenotype
bfile=opt$bfile
dir1=opt$workdir
dir2=opt$output

#####################################
# data prepare
#####################################

setwd(dir1)
# Full-featured function (Recommended)
MVP.Data(fileBed=bfile,
         filePhe=phe,
         sep.phe = "\t",
         fileKin=FALSE,
         filePC=FALSE,       
         #maxLine=10000,
         out="mvp.plink"
         )

MVP.Data.Kin(TRUE, mvp_prefix='mvp.plink', out='mvp')
MVP.Data.PC(TRUE, mvp_prefix='mvp.plink', pcs.keep=5)

genotype <- attach.big.matrix("mvp.plink.geno.desc")
phenotype <- read.table("mvp.plink.phe",head=TRUE)
map <- read.table("mvp.plink.geno.map" , head = TRUE)


Kinship <- attach.big.matrix("mvp.kin.desc")
Covariates <- bigmemory::as.matrix(attach.big.matrix("mvp.plink.pc.desc"))



#####################################
# GWAS
#####################################

setwd(dir2)

for(i in 3:ncol(phenotype)){
# for(i in 2:3){
  imMVP <- MVP(
    phe=phenotype[, c(1, i)],
    geno=genotype,
    map=map,
    K=Kinship,
    CV.GLM=Covariates,
    CV.glm=Covariates,
    CV.FarmCPU=Covariates,
    nPC.GLM=5,
    nPC.glm=3,
    nPC.FarmCPU=3,
    vc.method="BRENT",
    maxLine=10000, 
    ncpus = 20,
    method.bin="static", # "FaST-LMM", "static" (#only works for FarmCPU)
    threshold=0.05,
    method=c("GLM", "glm", "FarmCPU")
  )
  gc()
}

