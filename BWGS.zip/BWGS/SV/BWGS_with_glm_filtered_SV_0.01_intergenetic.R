# /*************************************************************************
#   @ File Name    : BWGS_with_SV_and_SNP
#   @ Author       : lunping.liang
#   @ Mail         : lunping98@gmail.com
#   @ Version      : V1
#   @ Desc         : Script purpose description
#       @ Input Files:
#           - Phenotype file        : $ARGV[0]
#           - SNP genotype file     : $ARGV[1]
#           - SV  genotype file     : $ARGV[2]
#           - Trait list file       : $ARGV[3]
#       @ Output Files:
#           - Model‑specific prediction results: each model is saved as
#               "305_SNP_with_SV_<trait>_<model>_ac.csv"
#           - SNP count summary file: snp_counts.csv
# ************************************************************************/

#####################################
# Environment preparation
#####################################
# Load required R packages, clear the workspace, set working directory

library(pacman)
p_load(bruceR, rrBLUP, BGLR, brnn, glmnet, e1071, randomForest, BWGS,
       argparse, plyr, dplyr, tidyr, purrr)
library(GenomicRanges)
library(rtracklayer)
rm(list = ls())

#####################################
# Argument parsing
#####################################

parser <- ArgumentParser(
  description = "Genomic selection (GS) pipeline: processes phenotype & genotype data and saves model predictions."
)

# Arguments: phenotype file, SNP genotype file, SV genotype file,
# working directory, and trait list file
parser$add_argument("-p", "--pheno", type = "character", required = TRUE,
                    help = "Path to the phenotype file; should contain all samples and one column per trait.",
                    metavar = "PhenoFile")
parser$add_argument("-s", "--snp", type = "character", required = TRUE,
                    help = "Path to the SNP genotype file (usually a matrix of SNP genotypes).",
                    metavar = "SnpGenoFile")
parser$add_argument("-S", "--sv", type = "character", required = TRUE,
                    help = "Path to the SV genotype file containing genotypes at SV loci for each sample.",
                    metavar = "SvGenoFile")
parser$add_argument("-t", "--trait", type = "character", required = TRUE,
                    help = "Path to the trait list file; one trait name per line.",
                    metavar = "TraitListFile")
parser$add_argument("-w", "--work", type = "character", required = TRUE,
                    help = "Absolute path to the working directory (holds both input and output files).",
                    metavar = "WorkDir")

# Parse command‑line arguments
opt            <- parser$parse_args()
work_dir       <- opt$work
sv_geno_file   <- opt$sv
snp_geno_file  <- opt$snp
pheno_file     <- opt$pheno
traits_file    <- opt$trait


#####################################
# Data loading
#####################################
setwd(work_dir)

load(sv_geno_file)
sv_geno <- myGD_mat
rm(myGD_mat)

load(snp_geno_file)
snp_geno <- myGD_mat
rm(myGD_mat)

load(pheno_file)
pheno <- a
rm(a)

traits      <- fread(traits_file, header = FALSE)
trait_list  <- traits$V1   # Retrieve all trait names

#####################################
# Loop over each trait
#####################################
promoter_upstream_bp <- 2000     # Promoter length upstream of TSS

# Store the number of SVs retained for each trait
sv_counts <- data.frame(trait = character(),
                        sv_count = integer(),
                        stringsAsFactors = FALSE)

# ----------------- Build combined gene + promoter regions -----------------
genes_gr <- import("input/pan.gff3")
genes_gr <- genes_gr[genes_gr$type == "gene"]

# (1) Create promoter regions (upstream of TSS)
promoters_gr <- promoters(genes_gr,
                          upstream   = promoter_upstream_bp,
                          downstream = 0)

# (2) Combine gene bodies and promoters, then merge overlaps
genic_and_promoter_regions <- reduce(c(genes_gr, promoters_gr))

# SV meta‑information
meta <- fread("input/sv_meta1.tsv",
              col.names = c("CHROM", "POS", "ID", "SVTYPE",
                            "END_raw", "SVLEN", "CHR2", "POS2"))

# ----------------- Main analysis per trait -----------------
walk(trait_list, function(trait) {

  #####################################
  # SV filtering & extraction
  #####################################
  raw_sv_file <- paste(work_dir, "/input/SV_GLM/",
                       trait, ".GLM.csv", sep = "")
  raw_sv <- fread(raw_sv_file)

  # Rename column and attach P‑values
  colnames(raw_sv)[8] <- "Pvalue"
  if (!"ID" %in% names(raw_sv))
    raw_sv[, ID := paste0(CHROM, "-", POS)]

  sv <- merge(raw_sv, meta, by = c("CHROM", "POS"), all.x = TRUE)

  ## ===== 1. Compute START / END coordinates =====
  sv[, `:=`(START = POS,            # default
            END   = POS)]           # overwritten below if needed

  ## 1A. DEL / DUP / INV with END_raw already known
  sv[SVTYPE %chin% c("DEL", "DUP", "INV") &
     !is.na(END_raw) & END_raw != ".",
     END := as.integer(END_raw)]

  ## 1B. DEL / DUP / INV with only SVLEN
  sv[SVTYPE %chin% c("DEL", "DUP", "INV") &
     is.na(END_raw) & !is.na(SVLEN) & SVLEN != ".",
     END := POS + abs(as.integer(SVLEN))]

  ## 1C. INS / BND keep 1‑bp interval (END = POS)

  ## ===== 2. Create GRanges for breakpoint 1 =====
  gr1 <- makeGRangesFromDataFrame(
    sv, seqnames.field = "CHROM",
    start.field = "START", end.field = "END",
    keep.extra.columns = TRUE, ignore.strand = TRUE)
  gr1$idx <- seq_len(nrow(sv))  # store row index

  ## ===== 3. Create GRanges for breakpoint 2 of BNDs (if present) =====
  bnd_mask <- sv$SVTYPE == "BND" &
              !is.na(sv$CHR2) & sv$CHR2 != "." &
              !is.na(sv$POS2) & sv$POS2 != "."
  gr2 <- GRanges(
    seqnames = sv$CHR2[bnd_mask],
    ranges   = IRanges(start = as.integer(sv$POS2[bnd_mask]),
                       end   = as.integer(sv$POS2[bnd_mask])),
    idx      = which(bnd_mask)
  )

  ## Keep only chromosomes in common across datasets
  common <- intersect(seqlevels(genic_and_promoter_regions),
                      unique(c(seqlevels(gr1), seqlevels(gr2))))
  genic_and_promoter_regions <- keepSeqlevels(genic_and_promoter_regions,
                                              common, pruning.mode = "coarse")
  gr1 <- keepSeqlevels(gr1, common, pruning.mode = "coarse")
  if (length(gr2) > 0) {
    common2 <- intersect(seqlevels(gr2),
                         seqlevels(genic_and_promoter_regions))
    gr2 <- keepSeqlevels(gr2, common2, pruning.mode = "coarse")
  }

  ## ===== 4. Determine overlaps =====
  sv[, `:=`(End1_genic = FALSE, End2_genic = NA)]   # initialise flags

  # Breakpoint 1
  hit1 <- queryHits(findOverlaps(gr1, genic_and_promoter_regions,
                                 ignore.strand = TRUE))
  sv$End1_genic[gr1$idx[hit1]] <- TRUE

  # Breakpoint 2
  if (length(gr2) > 0) {
    hit2 <- queryHits(findOverlaps(gr2, genic_and_promoter_regions,
                                   ignore.strand = TRUE))
    sv$End2_genic <- FALSE
    sv$End2_genic[gr2$idx[hit2]] <- TRUE
  }

  # Label SVs: genic if either breakpoint overlaps, otherwise intergenic
  sv[, Region := fifelse(End1_genic | (End2_genic %in% TRUE),
                         "genic", "intergenic")]

  # Retain intergenic SVs with P‑value < 0.01
  filter_sv <- sv[Region == "intergenic"] |>
    filter(Pvalue < 0.01) |>
    select(CHROM, POS) |>
    mutate(num = 1) |>
    unite(snp_id, CHROM, POS, num, sep = "_", remove = FALSE)

  print(head(filter_sv))

  # Keep SVs present in the genotype matrix
  valid_sv_ids     <- filter_sv$snp_id[filter_sv$snp_id %in% colnames(sv_geno)]
  sv_geno_filtered <- sv_geno[, valid_sv_ids]

  # Record count
  sv_count  <- length(valid_sv_ids)
  sv_counts <<- rbind(sv_counts, data.frame(trait   = trait,
                                            sv_count = sv_count))

  # (If desired) Combine SNP & SV matrices — here we use only SVs
  geno <- sv_geno_filtered

  # Extract phenotype vector
  ZB1 <- pheno[, trait]
  names(ZB1) <- pheno[, 1]

  #####################################
  # Core GS analysis
  #####################################
  models      <- c("GBLUP", "RF", "EGBLUP", "RR", "BRR",
                   "LASSO", "EN", "BL", "BB", "RKHS")
  file_prefix <- paste(work_dir,
                       "/output/305_glm_filtered_intergenic_SV_0.01",
                       trait, sep = "")
  file_names  <- paste0(file_prefix, "_", models, "_ac.csv")

  # Run each model and save cross‑validation results
  results <- map2(models, file_names, ~{
    model_name  <- .x
    output_file <- .y
    result <- bwgs.cv(geno, ZB1,
                      geno.impute.method = "mni",
                      predict.method     = model_name,
                      nFolds             = 5,
                      nTimes             = 10)
    write.csv(result$cv, output_file)
    result$cv
  })

  # Combine CV results from all models
  all_model_results <- do.call(cbind, results)
  colnames(all_model_results) <- models

  # Save combined statistics
  write.csv(all_model_results,
            paste0(file_prefix, "_all_model_ac.csv"))
})

# Save SV counts per trait
write.csv(sv_counts,
          paste(work_dir, "/output/glm_filtered_intergenic_sv_0.01_counts.csv",
                sep = ""),
          row.names = FALSE)
