Rscript BWGS_with_mlm_filtered_SV_0.01.R -p input/305_phe.RData -S input/305_SV_Geno.RData -t input/tratis.list.txt -w /data/GS/305/SV

